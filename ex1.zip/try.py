import tensorflow as tf

import numpy as np
tf.compat.v1.enable_eager_execution()
batch = 3
a = tf.constant([[[1,1],[1,1]], [[2,2],[2,2]],[[3,3],[3,3]]])



batch_size = 64
# load data
fashion_mnist = tf.keras.datasets.fashion_mnist
(train_images, train_labels), (test_images, test_labels) = fashion_mnist.load_data()


dataset = tf.data.Dataset.from_tensor_slices((train_images,train_labels)).repeat().batch(batch_size)
data_iter = dataset.make_one_shot_iterator()

counter = 0
lastx = None
for x, y in data_iter:
    print(x.shape, y.shape)
    print(x == lastx)
    lastx = x
    if counter == 5:
        break
    counter += 1



# print(train_images.shape)
# print(tf.split(train_images, 64))
# print(tf.math.argmax(train_labels))




indices = np.random.choice(num_train_samples, batch_size)
x_batch = x_train[indices]
y_batch = y_train[indices]



















import tensorflow as tf
import numpy as np
import operations as op
import matplotlib.pyplot as plt
from math import ceil


def load_data():
    from sklearn.datasets import load_boston
    boston_dataset = load_boston()
    X = np.array(boston_dataset.data)
    y = np.array(boston_dataset.target)
    return X, y


def model(x: tf.Tensor):
    """
    linear regression model: y_predict = W*x + b
    please use your matrix multiplication implementation.
    :param x: symbolic tensor with shape (batch, dim)
    :return:  a tuple that contains: 1.symbolic tensor y_predict, 2. list of the variables used in the model: [W, b]
                the result shape is (batch)
    """
    _, dimension = x.shape
    W = tf.get_variable(name='weights', shape=[dimension, 1],  dtype=tf.float32, trainable=True)
    b = tf.get_variable(name='bias', shape=[1, ],  dtype=tf.float32, trainable=True)
    # y_predict = op.matmul_tf(x, W) + b
    y_predict = tf.add(op.matmul_tf(x, W), b)
    return y_predict, [W, b]


def train(epochs, learning_rate, batch_size):
    """
    create linear regression using model() function from above and train it on boston houses dataset using batch-SGD.
    please normalize your data as a pre-processing step.
    please use your mse-loss implementation.
    :param epochs: number of epochs
    :param learning_rate: the learning rate of the SGD
    :return: list contains the mean loss from each epoch.
    """
    x, y = load_data()
    
    # preprocess
    x = tf.keras.utils.normalize(x, axis=1)

    num_samples, dimension = x.shape
    # split = ceil(0.85*num_samples)
    # x_train = x[:split]
    # y_train = y[:split]
    # x_test = x[split:]
    # y_test = y[split:]

    # num_train_samples, _ = x_train.shape
    # n_batches = ceil(num_train_samples/batch_size)
    n_batches = ceil(num_samples/batch_size)

    # create model
    X = tf.placeholder(tf.float32, shape=[None, dimension],name="X")
    Y = tf.placeholder(tf.float32, shape=[None], name="Y")
    predictions, weights = model(X)
    [W, b] = weights
    loss = op.mse_tf(Y, predictions)
    gradients = tf.gradients(ys=[loss], xs=[W, b], name="gradients")
    weights_update = tf.assign_sub(W, learning_rate*gradients[0])
    bias_update = tf.assign_sub(b, learning_rate*gradients[1])
    update = tf.group(weights_update, bias_update, name="grad_des")
    
    # define some constants
    epoch_loss = []
    test_loss = []
    epoch_cost = 0
    
    print("Starting Training Loop....\n")
    with tf.Session() as sess:
        sess.run(tf.global_variables_initializer())
        for epoch in range(epochs):
            for i in range(n_batches):
                start = batch_size * i
                end = start + batch_size
                if i == n_batches - 1:
                    end = num_samples
                # x_batch = x_train[start:end]
                # y_batch = y_train[start:end]
                x_batch = x[start:end]
                y_batch = y[start:end]
                cost, _ = sess.run([loss, update], feed_dict={X: x_batch, Y: y_batch})  # cost is of 1 x batch_size

                epoch_cost += (np.average(cost) / n_batches)  # average over all samples, and over batches in epoch
            
            epoch_loss.append(epoch_cost)


            # print("Epoch Number: {}, Loss: {:.4f}".format(epoch, epoch_cost))
            
            epoch_cost = 0

            # shuffle data for next epoch
            randomize = np.arange(num_samples)
            np.random.shuffle(randomize)
            x, y = x[randomize], y[randomize]

            # randomize = np.arange(num_train_samples)
            # np.random.shuffle(randomize)
            # x_train, y_train = x_train[randomize], y_train[randomize]

            # Test Model
            # test_cost = sess.run([loss], feed_dict={X: x_test, Y: y_test})
            # test_loss.append(np.average(test_cost))

    return epoch_loss

